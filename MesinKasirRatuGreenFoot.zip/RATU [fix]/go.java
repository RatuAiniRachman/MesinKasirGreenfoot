import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class go here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class go extends Actor
{
    /**
     * Act - do whatever the go wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    boolean x=true;
    public void act() 
    {
        // Add your action code here.
         if (Greenfoot.mouseClicked(this)&&x==true){
            World w=getWorld();
            ((Dunia)w).getData().simpan();
        }
        if(Greenfoot.mouseClicked(this)&&x==false){
            ((Bayar)getWorld()).hit.prtHit();
        }
    }    
}
