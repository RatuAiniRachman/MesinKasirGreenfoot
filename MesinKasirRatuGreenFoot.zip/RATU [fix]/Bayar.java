import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;
import java.awt.Color;
import java.awt.Font;
/**
 * Write a description of class Bayar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bayar extends World
{
    
     //public Data total;
     
    Kasir ks0 = new Kasir("nol.png"); 
    Kasir ks1 = new Kasir("satu.png"); 
    Kasir ks2 = new Kasir("dua.png"); 
    Kasir ks3 = new Kasir("tiga.png"); 
    Kasir ks4 = new Kasir("empat.png"); 
    Kasir ks5 = new Kasir("lima.png"); 
    Kasir ks6 = new Kasir("enam.png"); 
    Kasir ks7 = new Kasir("tujuh.png"); 
    Kasir ks8 = new Kasir("delapan.png"); 
    Kasir ks9 = new Kasir("sembilan.png"); 
    Kasir ksx = new Kasir("x.png");
    Data kal = new Data();
    go ksr = new go();
    Data hit = new Data();
    Data tot = new Data();
    
    public Bayar()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
         super(810, 600, 1); 
        addObject(new Keluar(),477,546);
        addObject(ksr,452,143); ksr.x=false;
               
        tes();
    }
    
    
    private void tes()
    {
      
            addObject(ks0, 206, 552); ks0.setVal(0);
            addObject(ks1, 204, 298); ks1.setVal(1);
            addObject(ks2, 299, 298); ks2.setVal(2);
            addObject(ks3, 398, 298); ks3.setVal(3);
            addObject(ks4, 204, 387); ks4.setVal(4);
            addObject(ks5, 300, 386); ks5.setVal(5);
            addObject(ks6, 397, 386); ks6.setVal(6);
            addObject(ks7, 205, 475); ks7.setVal(7);
            addObject(ks8, 300, 475); ks8.setVal(8);
            addObject(ks9, 400, 475); ks9.setVal(9);
            addObject(ksx, 400, 552); ksx.setVal(10);
            
            addObject(kal,202,107); //input bayar
            addObject(hit,680,317); //bayar - total belanja
            addObject(tot,679,120); //Link --> total belanja ke world 2
            tot.print="TOTAL \n"+tot.getTtl()+""; //total belanja
            }
            
    
}
