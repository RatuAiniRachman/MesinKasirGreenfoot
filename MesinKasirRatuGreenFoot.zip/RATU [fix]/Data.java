import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.awt.*;
/**
 * Write a description of class semua here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Data extends Actor
{
    /**
     * Act - do whatever the semua wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public String print=" - ";
    private String nama;
    private int harga;
    private int idx=1;
    public int font_size=58;
    private int amount=0;
    public static int ttl=0;
    public Color warna=Color.orange;
    private int tKal=0;
    private int hit;
    
    public void act() 
    {
        // Add your action code here.
        setImage(new GreenfootImage(print,font_size,warna,null));
        
    }    

    public void setPrint(String a,int b){print=a+"\n Rp "+b; harga=b; nama=a; //setPrint dari Menu makanan
        World w=getWorld();
        ((Dunia)w).getAmount().reset();
        ((Dunia)w).getAmount().amountPlus();
        
    }
    
    public void setPrt(int x){ //kasir started
        tKal= tKal*10 +x;
        if(x==10){tKal=0;}
        print="Cash :\n"+"Rp. "+tKal+"";
    }
    
    public void prtHit(){ //Kembalian --> Bayar - Biaya Belanja
        hit=((Bayar)getWorld()).kal.tKal-ttl;
        print="change :\n"+hit+"";
    }
    
    public void getA(){
        World w=getWorld();
        amount = ((Dunia)w).getAmount().getA();
    }
    
    public void simpan(){ // MENU MENU
        getA();
        if(idx==1){
            Data data1 = new Data();
            getWorld().addObject(data1,690,100);
            data1.harga = harga*amount; //dikali amount(kuantitas)
            data1.amount=amount;
            data1.nama = nama;
            data1.font_size=20;
            data1.print = data1.nama+" ("+amount+") "+data1.harga;
            ttl+=data1.harga;
        }
        if(idx==2){
            Data data2 = new Data();
            getWorld().addObject(data2,690,130);
            data2.harga = harga*amount;
            data2.nama = nama;
            data2.font_size=20;
            data2.print = data2.nama+" ("+amount+") "+data2.harga;
            ttl+=data2.harga;
        }
        if(idx==3){ //side bar (calculation)
            Data data3 = new Data();
            getWorld().addObject(data3,690,160);
            data3.harga = harga*amount;
            data3.nama = nama;
            data3.font_size=20;
            data3.print = data3.nama+" ("+amount+") "+data3.harga;
            ttl+=data3.harga;
        }
        if(idx==4){ //kembalian --dkk
            Data data4 = new Data();
            getWorld().addObject(data4,690,190);
            data4.harga = harga*amount;
            data4.nama = nama;
            data4.font_size=20;
            data4.print = data4.nama+" ("+amount+") "+data4.harga;
            ttl+=data4.harga;
        }
        if(idx==5){ //when calculation clicked
            Data data5 = new Data();
            getWorld().addObject(data5,690,220);
            data5.harga = harga*amount;
            data5.nama = nama;
            data5.font_size=20;
            data5.print = data5.nama+" ("+amount+") "+data5.harga;
            ttl+=data5.harga;
        }
        if(idx==6){ //world 1,when menu clicked (price)
            Data data6 = new Data();
            getWorld().addObject(data6,690,250);
            data6.harga = harga*amount;
            data6.nama = nama;
            data6.font_size=20;
            data6.print = data6.nama+" ("+amount+") "+data6.harga;
            ttl+=data6.harga;
        }
        //TOTAL BELANJA
        World w=getWorld();
        ((Dunia)w).total.print = "TOTAL :\n"+ttl;
        idx++;
    }
     
     public int getTtl(){return ttl;}
}
