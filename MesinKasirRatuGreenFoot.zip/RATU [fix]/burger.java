import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class burger here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class burger extends Actor
{
    /**
     * Act - do whatever the burger wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this))
        {
            World w=getWorld();
            ((Dunia)w).getData().setPrint("Burger",15000); //setPrint dari clas data
        }
    }    
}
