import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class pudding here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pudding extends Actor
{
    
    /**
     * Act - do whatever the pudding wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this))
        {
            World w=getWorld();
            ((Dunia)w).getData().setPrint("Pudding",5000);//setPrint dari clas data
        }
        
         
}
}

