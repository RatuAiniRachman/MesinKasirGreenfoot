import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo
import java.awt.*;

public class Dunia extends World{

    public Data data;
    public go masukkan;
    public Amount amount;
    public Data total;
  
    public Dunia()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(810, 600, 1); 
        prepare();
         
    }
    private void prepare()
    {

                pudding pudding = new pudding();
                addObject(pudding, 100, 330);
                soup soup= new soup();
                addObject(soup, 273, 330);
                twisty twisty = new twisty();
                addObject(twisty, 445, 330);
                fishFillet fishFillet = new fishFillet();
                addObject(fishFillet, 100, 510);
                burger burger = new burger();
                addObject(burger, 273, 510);
                ayam ayam = new ayam();
                addObject(ayam, 445, 510);
        
        data = new Data();
        addObject(data,200,130);
        masukkan = new go();
        addObject(masukkan, 426, 149);
        amount = new Amount();
        addObject(amount, 331,133);
        Plus plus = new Plus();
        addObject(plus, 385,70);
        Min min = new Min();
        addObject(min, 457,70);
        total = new Data();
        addObject(total,676,347);
        total.warna=Color.cyan;
        Hitung hitung = new Hitung();
        addObject(hitung, 688, 529);
        
        data.ttl=0;
    } 
    
    public Data getData(){return data;}
    public Amount getAmount(){return amount;}
    public Data getTotal(){return total;}
}

     

