import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class soup here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class soup extends Actor
{
    /**
     * Act - do whatever the soup wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this))
        {
            World w=getWorld();
            ((Dunia)w).getData().setPrint("Soup",8000);
        }
    }    
}
