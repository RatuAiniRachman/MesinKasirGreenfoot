import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class fishFillet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class fishFillet extends Actor
{
    /**
     * Act - do whatever the fishFillet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.mouseClicked(this))
        {
            World w=getWorld();
            ((Dunia)w).getData().setPrint("Fish Fillet",17000);
        }
    }    
}
