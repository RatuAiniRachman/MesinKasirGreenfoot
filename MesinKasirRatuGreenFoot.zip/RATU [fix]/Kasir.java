import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Kasir here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Kasir extends Actor
{
   private String nama;
   private int val;
    /**
     * Act - do whatever the CD1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Kasir(String gambar)
    {
        GreenfootImage gbr = new GreenfootImage(gambar);
        setImage(gbr);
    }
    
    public void act(){
        klik();
    }
    
    public void klik(){
        if(Greenfoot.mouseClicked(this)){
        ((Bayar)getWorld()).kal.setPrt(val);
        }
    }
    public void setVal(int x){val=x;}
}
